<!DOCTYPE html>
<html>
	
<head>
		<title>APPLES INC. Client Portal</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		
		<!-- Bootstrap CSS -->
		<link href="/authasset/css/bootstrap.css" rel="stylesheet" media="screen">

		<!-- Main CSS -->
		<link href="/authasset/css/main.css" rel="stylesheet" media="screen">

		<!-- Font Awesome CSS -->
		<link href="/authasset/fonts/font-awesome.css" rel="stylesheet">
		<!--[if IE 7]>
			<link rel="stylesheet" href="fonts/font-awesome.css">
		<![endif]-->

		<!-- HTML5 shiv and Respond.js IE8 support of HTML5 elements and media queries -->
		<!--[if lt IE 9]>
			<script src="js/html5shiv.js"></script>
			<script src="js/respond.min.js"></script>
		<![endif]-->
	</head>
	<body style="background:#e1e6e9 url(/authasset/img/bg.jpg)">


	@yield('content')

	</body>

</html>
